/* ************************************************************************

 Copyright:

 License:

 Authors:

 ************************************************************************ */
// import 'style/tachyons.4.11.2.css';
// import 'style/animate.4.0.0.css';

import 'tweenjs';
import * as component from 'src/component';


// 程式進入點
component.run();

console.log('zz');

