import * as main from 'makeres/main';
import * as sub from 'makeres/sub';
import * as load from 'makeres/load';
import * as info from 'makeres/info';

export {
  main,
  sub,
  load,
  info
};
