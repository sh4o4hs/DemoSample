let Command = {
  handle (data) {
    console.log('[client:updateBalance]' + data);
  }
};

export default Command;
