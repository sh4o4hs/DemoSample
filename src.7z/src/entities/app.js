
let app = {};

app.isChild = false;         // 是否為子視窗
app.decimal = 0;             // 設定小數位數
app.baseURL = '';

export default app;

